import pygame
import random
size = width, height = 800, 600
white = 0xFF, 0xFF, 0xFF
black = 0x00, 0x00, 0x00

class Move:
    Up = False
    Down = False
    Right = False
    Left = False
    ByMouse = False


def main():
    pygame.init()
    screen = pygame.display.set_mode(size)
    gameover = False
    x = 400
    y = 300
    deltax = random.randint(-5, 5)
    deltay = random.randint(-5, 5)
    ball = pygame.image.load("basketball.png");
    b_rect = ball.get_size()
    #print(b_rect)
    platform_size = (100, 20)
    platform_pos = (400, 300)
    while not gameover:
        for event in pygame.event.get():  # Получение всех событий
            gameover = process_events(platform_size, event, gameover)
        screen.fill(white)
        platform_pos = process_moving(platform_pos, platform_size)
       # print(platform_pos)
        pygame.draw.polygon(screen, black, list([platform_pos,
                                           (platform_pos[0] + platform_size[0], platform_pos[1]),
                                           (platform_pos[0] + platform_size[0], platform_pos[1] + platform_size[1]),
                                            (platform_pos[0], platform_pos[1] + platform_size[1])]))
        if x + deltax > size[0] - b_rect[1] or x + deltax < 00:
            deltax *= -1
        if y + deltay > size[1] - b_rect[1] or y + deltay < 00:
            deltay *= -1
        x += deltax
        y += deltay
        point = (x, y)
        screen.blit(ball, point)
        pygame.display.flip()
        pygame.time.wait(10)
def process_events(b_rect, event, gameover):
    if event.type == pygame.QUIT:  # Событие выхода
        gameover = True
    elif event.type == pygame.KEYDOWN:
        press_key_down(event)
        print(1)
    elif event.type == pygame.KEYUP:
        press_key_up(event)

    return gameover


def process_moving(bb_rect, sizee):
    if Move.Right and bb_rect[0] + sizee[0] + 1 < size[0]:
        x, y = bb_rect
        x += 1
        bb_rect = x, y
    if Move.Left and bb_rect[0] - 1 > 0:
        x, y = bb_rect
        x -= 1
        bb_rect = x, y

    if Move.Up:
        bb_rect.y -= 1
    if Move.Down:
        bb_rect.y += 1

    return bb_rect


def press_key_up(event):
    if (event.key == pygame.K_d):
        Move.Right = False
    elif (event.key == pygame.K_a):
        Move.Left = False


def press_key_down(event):
    if (event.key == pygame.K_a):
        Move.Left = True
    if (event.key == pygame.K_d):
        Move.Right = True

if __name__ == '__main__':
    main()