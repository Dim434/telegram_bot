import pygame
import sys

size = width, height = 320, 240  # Размеры экрана
black = 0, 0, 0  # Чёрный цвет (RGB)
pygame.init()  # Инициализация библиотеки
screen = pygame.display.set_mode(size)  # Установка размеров окна
class Move:
    Up = False
    Down = False
    Right = False
    Left = False
    ByMouse = False

class Button:
    def __init__(self, position, sizee, color, changedcolor, text, function, *args):
        self.pos = position
        self.size = sizee
        self.function = function
        self.color = color
        self.args = args
        self.stcolor = color
        self.tocolor = changedcolor
        font = pygame.font.Font(None, 25)
        self.text = font.render(text, True, black)
        self.at = False
    def draw(self):
        pygame.draw.polygon(screen, self.color, (
            self.pos, (self.pos[0] + self.size[0], self.pos[0]),
            (self.pos[0] + self.size[0], self.pos[1] + self.size[1]),
            (self.pos[0], self.pos[1] + self.size[1])))

        screen.blit(self.text, self.pos)

    def check_button(self, pos):
        if pos[0] >= self.pos[0] and pos[0] <= self.pos[0] + self.size[0] and pos[1] >= self.pos[1] and pos[1] <= self.pos[1] + self.size[1]:
            self.color= self.tocolor
            self.at = True
            pass
        else:
            self.color = self.stcolor
            self.at = False
    def do_func(self):

        return self.function(*self.args)


def main():
    gameover = False
    ball =pygame.image.load("basketball.png")
    b_rect = ball.get_rect()
    b_rect.x = 100
    b_rect.y =120
    moving_right = False
    i = Button((0, 0), (100, 100), (255, 255, 255),(0,0,255), "DEF", print, 123)
    while not gameover:  # Основной цикл

        for event in pygame.event.get():  # Получение всех событий
            gameover = process_events(b_rect, event, gameover, i)

        b_rect = process_moving(b_rect)
        process_moving(b_rect)
        screen.fill(black)  # Заливка цветом
        i.draw()
        screen.blit(ball, b_rect)
        pygame.display.flip()  # Double buffering
        pygame.time.wait(10)  # Ожидание отрисовки


    sys.exit()


def process_events(b_rect, event, gameover, but):
    if event.type == pygame.QUIT:  # Событие выхода
        gameover = True
    elif event.type == pygame.KEYDOWN:
        event_on_key_down(event)
    elif event.type == pygame.KEYUP:
        press_key_up(event)
    elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 2:
        Move.ByMouse = True
    elif event.type == pygame.MOUSEBUTTONUP and event.button ==2:
        Move.ByMouse = False
    elif event.type == pygame.MOUSEMOTION and Move.ByMouse == True:
        x, y = event.pos
        b_rect.x = x - b_rect.width // 2
        b_rect.y = y - b_rect.width // 2
    if(event.type == pygame.MOUSEMOTION):
        but.check_button((event.pos[0], event.pos[1]))
    if(event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and but.at == True):
        but.do_func()

    return gameover


def process_moving(b_rect):
    if Move.Right:
        b_rect.x += 1
    if Move.Left:
        b_rect.x -= 1
    if Move.Up:
        b_rect.y -= 1
    if Move.Down:
        b_rect.y += 1

    return b_rect


def press_key_up(event):
    if (event.key == pygame.K_d):
        Move.Right = False
    elif (event.key == pygame.K_a):
        Move.Left = False
    elif (event.key == pygame.K_w):
        Move.Up = False
    elif (event.key == pygame.K_s):
        Move.Down = False


def event_on_key_down(event):
    if (event.key == pygame.K_w):
        Move.Up = True
    if (event.key == pygame.K_s):
        Move.Down = True
    if (event.key == pygame.K_a):
        Move.Left = True
    if (event.key == pygame.K_d):
        Move.Right = True


if __name__ == "__main__":
    main()